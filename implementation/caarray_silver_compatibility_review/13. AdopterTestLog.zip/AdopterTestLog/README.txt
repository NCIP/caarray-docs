Adopter Test Log
----------------

The test clients/scripts are in caArrayApiWithGridClient with a README.txt that describes how to run them.

The output from one test run is provided in caArrayApiWithGridClient/testLog.txt.

