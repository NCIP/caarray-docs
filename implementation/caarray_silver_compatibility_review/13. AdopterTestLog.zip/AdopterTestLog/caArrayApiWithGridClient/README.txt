Java client to test the CaArray Remote Java API and Grid Service:
-----------------------------------------------------------------

1. Before running the tests:
   a. Import the Test3.cdf array design (available under data/).
   b. Create an experiment with array provider = Affymetrix and organism = Homo sapiens that uses Test3.
   c. Import specification.zip into it (available under data/).
   d. Make the experiment public.
2. Please set the right server name, jndi port and grid service port in src/gov/nih/nci/caarray/test/client/BaseApiClient.java.
3. The Ant file build.xml provides targets to compile and run the test client.
4. All jar dependencies including the caArray client jar and the caArray Grid Service client jars are present in the lib directory.
5. ant clean
   ant compile
   // To test the Remote Java API:
   ant runExampleSearch
   ant runCQLSearch
   ant runFileDownload
   ant runArrayDesignDownload
   ant runDataSetDownload
   ant runOneFileDataSetDownload
   // To test the CaArray Grid Service API:
   ant runGridCQLSearch
   ant runGridFileDownload
   ant runGridArrayDesignDownload
   ant runGridDataSetDownload
6. Redirect STDOUT to a file from all the above tests if you want to save the test output. The output from one test run is provided in testLog.txt.

