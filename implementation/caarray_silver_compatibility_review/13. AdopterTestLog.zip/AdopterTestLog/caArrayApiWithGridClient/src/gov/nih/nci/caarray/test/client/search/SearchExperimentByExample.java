package gov.nih.nci.caarray.test.client.search;

import edu.georgetown.pir.Organism;
import gov.nih.nci.caarray.domain.contact.Organization;
import gov.nih.nci.caarray.domain.project.Experiment;
import gov.nih.nci.caarray.services.CaArrayServer;
import gov.nih.nci.caarray.services.search.CaArraySearchService;
import gov.nih.nci.caarray.test.client.BaseApiClient;

import java.util.Iterator;
import java.util.List;

/**
 * A client searching for experiments using search-by-example through CaArray's Remote Java API.
 *
 * @author Rashmi Srinivasa
 */
public class SearchExperimentByExample extends BaseApiClient {
    private static final String DEFAULT_MANUFACTURER_NAME = "Affymetrix";
    private static final String DEFAULT_ORGANISM_NAME = "human";

    public static void main(String[] args) {
        Experiment exampleExperiment = createExampleExperiment();
        try {
            CaArrayServer server = new CaArrayServer(SERVER_NAME, JNDI_PORT);
            server.connect();
            CaArraySearchService searchService = server.getSearchService();
            logOutput("****************************************");
            logOutput("SEARCHING BY EXAMPLE FOR Experiment...");
            List<Experiment> experimentList = searchService.search(exampleExperiment);
            logOutput("Called API method CaArraySearchService.search(T) where T extends AbstractCaArrayObject...");
            if (isResultOkay(experimentList)) {
                logOutput("Retrieved " + experimentList.size() + " experiments with array provider "
                        + DEFAULT_MANUFACTURER_NAME + " and organism " + DEFAULT_ORGANISM_NAME + ".");
            } else {
                logOutput("Error: Response did not match request. Retrieved " + experimentList.size() + " persons.");
            }
            for (Experiment experiment : experimentList) {
                logOutput("Called method getTitle() on Experiment: " + experiment.getTitle());
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    private static Experiment createExampleExperiment() {
        Experiment exampleExperiment = new Experiment();

        Organization organization = new Organization();
        organization.setName(DEFAULT_MANUFACTURER_NAME);
        organization.setProvider(true);
        exampleExperiment.setManufacturer(organization);

        Organism organismCriterion = new Organism();
        organismCriterion.setCommonName(DEFAULT_ORGANISM_NAME);
        exampleExperiment.setOrganism(organismCriterion);

        return exampleExperiment;
    }

    private static boolean isResultOkay(List<Experiment> experimentList) {
        if (experimentList.isEmpty()) {
            return true;
        }

        Iterator<Experiment> i = experimentList.iterator();
        while (i.hasNext()) {
            Experiment retrievedExperiment = i.next();
            // Check if retrieved experiment matches requested search criteria.
            logOutput("Calling method getManufacturer() on Experiment...");
            logOutput("Calling method getOrganism() on Experiment...");
            logOutput("Calling method getName() on Organization...");
            logOutput("Calling method getCommonName() on Organism...");
            if ((!DEFAULT_MANUFACTURER_NAME.equals(retrievedExperiment.getManufacturer().getName()))
                    || (!DEFAULT_ORGANISM_NAME.equals(retrievedExperiment.getOrganism().getCommonName()))) {
                return false;
            }
            // Check if retrieved experiment has mandatory fields.
            logOutput("Calling method getServiceType() on Experiment...");
            logOutput("Calling method getAssayType() on Experiment...");
            if ((retrievedExperiment.getTitle() == null) || (retrievedExperiment.getServiceType() == null)
                    || (retrievedExperiment.getAssayType() == null)) {
                return false;
            }
        }
        return true;
    }
}
