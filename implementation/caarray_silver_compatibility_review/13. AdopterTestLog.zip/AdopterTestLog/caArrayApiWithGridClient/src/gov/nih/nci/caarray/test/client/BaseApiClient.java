package gov.nih.nci.caarray.test.client;

abstract public class BaseApiClient {
    protected static final String SERVER_NAME = "localhost";
    protected static final int JNDI_PORT = 1099;
    protected static final int GRID_SERVICE_PORT = 8080;

    protected static void logOutput (String outputText) {
        System.out.println(outputText);
    }
}
